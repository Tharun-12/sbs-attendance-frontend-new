import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../Authcontext/Authcontext';
import { auth, db } from '../firebase/firebase'; // import db also
import landNestLogo from '../Assets/sbslogo.png';
import './Login.css';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      // Step 1: Sign in with Firebase
      const userCredential = await auth.signInWithEmailAndPassword(email, password);
      const user = userCredential.user;

      // Step 2: Fetch extra user details from Firestore
      const userDoc = await db.collection("users").doc(user.uid).get();

      if (userDoc.exists) {
        const userData = {
          uid: user.uid,
          email: user.email,
          ...userDoc.data()   // Merge Firestore data (name, mobile, role, etc.)
        };

        // Step 3: Save in AuthContext and sessionStorage
        login(userData);

        // Step 4: Redirect
        navigate('/attendance');
      } else {
        setError("User profile not found in database.");
      }

    } catch (err) {
      console.error(err);
      setError(err.message || 'Invalid email or password');
    }
  };

  return (
    <div className="userlogin-wrapper">
      <div className="userlogin-container">
        <img src={landNestLogo} alt="Land Nest Logo" className="userlogin-logo" />

        <h2 className="userlogin-title">Welcome Back</h2>
        {error && <p className="userlogin-error">{error}</p>}

        <form onSubmit={handleSubmit} className="userlogin-form">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="userlogin-input"
          />

          <div className="userlogin-password-field">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="userlogin-input"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="userlogin-toggle-password"
            >
              {showPassword ? '🙈' : '👁️'}
            </button>
          </div>

          <button type="submit" className="userlogin-btn">Sign In</button>
        </form>
      </div>
    </div>
  );
};

export default Login;
