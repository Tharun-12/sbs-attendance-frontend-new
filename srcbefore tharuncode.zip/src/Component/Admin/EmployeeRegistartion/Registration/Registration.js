// src/components/Register.js
import React, { useState } from "react";
import {
  Form,
  Button,
  Container,
  Row,
  Col,
  Card,
  Spinner,
  Alert,
} from "react-bootstrap";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";
import { auth, db } from "../../../firebase/firebase"; // firebase config
import Navbar from "../../../Shared/AdminSidebar/AdminSidebar";
import "../../../Layout/Collapse/Collapse.css";

const Register = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    address: "",
    role: "user",
    employeeId: "",
    designation: "",
    department: "",
    joiningDate: "",
    qualification: "",
    experience: "",
    skills: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess("");

    try {
      // Auto-generate password => Name@123
      const autoPassword = `${formData.name.split(" ")[0]}@123`;

      // Create user in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        formData.email,
        autoPassword
      );

      const user = userCredential.user;

      // Save extra data in Firestore
      await setDoc(doc(db, "users", user.uid), {
        uid: user.uid,
        name: formData.name,
        email: formData.email,
        mobile: formData.mobile,
        address: formData.address,
        role: formData.role,
        employeeId: formData.employeeId,
        designation: formData.designation,
        department: formData.department,
        joiningDate: formData.joiningDate,
        qualification: formData.qualification,
        experience: formData.experience,
        skills: formData.skills,
        defaultPassword: autoPassword, // stored in case admin needs it
        createdAt: new Date(),
      });

      setSuccess("Registration successful!");
      setFormData({
        name: "",
        email: "",
        mobile: "",
        address: "",
        role: "user",
        employeeId: "",
        designation: "",
        department: "",
        joiningDate: "",
        qualification: "",
        experience: "",
        skills: "",
      });
    } catch (err) {
      setError(err.message);
    }

    setLoading(false);
  };

  return (
    <div className="CollapseContainer">
      <Navbar onToggleSidebar={setCollapsed} />
      <div className={`Collapse ${collapsed ? "collapsed" : ""}`}>
        <Container className="mt-5">
          <Row className="justify-content-md-center">
            <Col md={8}>
              <Card className="p-4 shadow-sm">
                <h3 className="text-center ">Employee Registration</h3>

                {error && <Alert variant="danger">{error}</Alert>}
                {success && <Alert variant="success">{success}</Alert>}

               <Form onSubmit={handleSubmit}>
  {/* Basic Details */}
  <Row>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Full Name</Form.Label>
        <Form.Control
          type="text"
          name="name"
          placeholder="Enter full name"
          value={formData.name}
          onChange={handleChange}
          required
        />
      </Form.Group>
    </Col>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Email</Form.Label>
        <Form.Control
          type="email"
          name="email"
          placeholder="Enter email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </Form.Group>
    </Col>
  </Row>

  <Row>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Mobile Number</Form.Label>
        <Form.Control
          type="text"
          name="mobile"
          placeholder="Enter mobile number"
          value={formData.mobile}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Address</Form.Label>
        <Form.Control
          type="text"
          name="address"
          placeholder="Enter address"
          value={formData.address}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
  </Row>

  {/* Employee Details */}
  <h5 className="mt-4">Employee Details</h5>
  <Row>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Employee ID</Form.Label>
        <Form.Control
          type="text"
          name="employeeId"
          placeholder="Enter employee ID"
          value={formData.employeeId}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Designation</Form.Label>
        <Form.Control
          type="text"
          name="designation"
          placeholder="Enter designation"
          value={formData.designation}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
  </Row>

  <Row>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Department</Form.Label>
        <Form.Control
          type="text"
          name="department"
          placeholder="Enter department"
          value={formData.department}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Joining Date</Form.Label>
        <Form.Control
          type="date"
          name="joiningDate"
          value={formData.joiningDate}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
  </Row>

  {/* Education Details */}
  <h5 className="mt-4">Education & Skills</h5>
  <Row>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Qualification</Form.Label>
        <Form.Control
          type="text"
          name="qualification"
          placeholder="Enter highest qualification"
          value={formData.qualification}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
    <Col md={6}>
      <Form.Group className="mb-3">
        <Form.Label>Experience (Years)</Form.Label>
        <Form.Control
          type="number"
          name="experience"
          placeholder="Enter years of experience"
          value={formData.experience}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
  </Row>

  <Row>
    <Col md={12}>
      <Form.Group className="mb-3">
        <Form.Label>Skills</Form.Label>
        <Form.Control
          type="text"
          name="skills"
          placeholder="Enter skills (comma separated)"
          value={formData.skills}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>
  </Row>

  <div className="d-grid">
    <Button type="submit" variant="primary" disabled={loading}>
      {loading ? <Spinner animation="border" size="sm" /> : "Register"}
    </Button>
  </div>
</Form>

              </Card>
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  );
};

export default Register;
