// src/components/EmployeeDetails.js
import React, { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import { db } from "../../../firebase/firebase"; 
import ReusableTable from "../../../Layout/ReusableTable";
import Navbar from "../../../Shared/AdminSidebar/AdminSidebar";
import '../../../Layout/Collapse/Collapse.css';

const EmployeeDetails = () => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, "users"));
        const usersData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setEmployees(usersData);
      } catch (error) {
        console.error("Error fetching employees:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchEmployees();
  }, []);

  // Define table columns
  const columns = [
    {
      key: "sno",
      title: "S.No",
      render: (row, index) => index + 1, // Auto serial number
    },
    { key: "name", title: "Name" },
    { key: "email", title: "Email" },
    { key: "mobile", title: "Mobile" },
    { key: "role", title: "Role" },
    { key: "address", title: "Address" },
    
  ];

  return (
    <div className="CollapseContainer">
      <Navbar onToggleSidebar={setCollapsed} />
      <div className={`Collapse ${collapsed ? "collapsed" : ""}`}>

        {/* Top section with Add button */}
        <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "10px" }}>
          <button
            onClick={() => navigate("/employeeregister")}
            style={{
              backgroundColor: "#007bff",
              color: "#fff",
              border: "none",
              padding: "8px 16px",
              borderRadius: "6px",
              cursor: "pointer",
              fontSize: "14px",
            }}
          >
            + Add Employee
          </button>
        </div>

        {/* Employee Table */}
        <ReusableTable
          title="Employee Details"
          data={employees}
          columns={columns}
          initialEntriesPerPage={5}
          searchPlaceholder="Search employees..."
          showSearch={true}
          showEntriesSelector={true}
          showPagination={true}
        />

        {loading && <p style={{ textAlign: "center" }}>Loading employees...</p>}
      </div>
    </div>
  );
};

export default EmployeeDetails;
