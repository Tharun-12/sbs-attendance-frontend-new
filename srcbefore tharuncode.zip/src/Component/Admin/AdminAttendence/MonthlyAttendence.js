// src/components/MonthlyAttendance/MonthlyAttendance.js
import React, { useState, useEffect } from "react";
import { db } from "../../firebase/firebase";
import { collection, getDocs } from "firebase/firestore";
import { ThreeDots } from "react-loader-spinner";
import "./MonthlyAttendence.css";
import Navbar from "../../Shared/AdminSidebar/AdminSidebar";
import ReusableTable from "../../Layout/ReusableTable";
import '../../Layout/Collapse/Collapse.css';

function MonthlyAttendance() {
  // Utils
  const getFormattedMonth = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    return `${year}-${month}`;
  };

  const getMonthDates = (year, month) => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1));
  };

  const formatDateForKey = (date) => {
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const getAttendanceStatus = (userAttendance, dateKey, date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    date.setHours(0, 0, 0, 0);

    if (date > today) return ""; // Future dates

    const dayAttendance = userAttendance[dateKey];
    if (dayAttendance && dayAttendance.status === "Present") {
      return "P";
    } else {
      return "A";
    }
  };

  const [collapsed, setCollapsed] = useState(false);
  const [users, setUsers] = useState([]);
  const [attendanceData, setAttendanceData] = useState([]);
  const [currentDate] = useState(new Date());
  const [selectedMonth, setSelectedMonth] = useState(getFormattedMonth(new Date()));
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "users"));
      const userData = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setUsers(userData);
    } catch (error) {
      console.error("Error fetching users data: ", error);
    }
  };

  const fetchAttendance = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "attendance"));
      const attendance = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAttendanceData(attendance);
    } catch (error) {
      console.error("Error fetching attendance data: ", error);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchAttendance();

    // Simulate delay for loader
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  // Process data
  const processMonthlyAttendanceData = () => {
    const year = currentDate.getFullYear();
    const month = parseInt(selectedMonth.split("-")[1], 10) - 1;
    const monthDates = getMonthDates(year, month);
    const dateKeys = monthDates.map(formatDateForKey);

    return users.map((user) => {
      const userAttendance = attendanceData.find((entry) => entry.id === user.id) || {};
      let totalPresent = 0;

      const dailyStatuses = dateKeys.map((dateKey, index) => {
        const date = monthDates[index];
        const status = getAttendanceStatus(userAttendance, dateKey, new Date(date));
        if (status === "P") totalPresent++;
        return status;
      });

      return {
        id: user.id,
        name: user.fullName || "N/A",
        dailyStatuses,
        totalPresent,
      };
    });
  };

  const monthlyData = processMonthlyAttendanceData();

  // Table columns (dynamic days + total)
  const columns = [
    { key: "name", title: "User Name" },
    ...getMonthDates(currentDate.getFullYear(), parseInt(selectedMonth.split("-")[1], 10) - 1).map(
      (date, idx) => ({
        key: `day-${idx}`,
        title: date.getDate().toString().padStart(2, "0"),
        render: (row) => {
          const status = row.dailyStatuses[idx];
          return (
            <span
              style={{
                color: status === "P" ? "green" : status === "A" ? "red" : "black",
                fontWeight: "bold",
              }}
            >
              {status}
            </span>
          );
        },
      })
    ),
    { key: "totalPresent", title: "Total Present" },
  ];

  const currentYear = currentDate.getFullYear();
  const currentMonth = String(currentDate.getMonth() + 1).padStart(2, "0");
  const maxMonth = `${currentYear}-${currentMonth}`;

  if (loading) {
    return (
      <div className="loader-container">
        <ThreeDots height="80" width="80" radius="9" color="#00BFFF" ariaLabel="three-dots-loading" visible={true} />
      </div>
    );
  }

  return (
    <div className='CollapseContainer'>
      <Navbar onToggleSidebar={setCollapsed} />
      <div className={`Collapse ${collapsed ? 'collapsed' : ''}`}>
        <div className="d-flex justify-content-center">
          <h1 className="monthlyattendance-heading">
            Monthly Attendance for{" "}
            {new Date(currentDate.getFullYear(), parseInt(selectedMonth.split("-")[1], 10) - 1).toLocaleString(
              "default",
              { month: "long" }
            )}{" "}
            {currentDate.getFullYear()}
          </h1>
        </div>

        <div className="monthly-filter-container">
          <label htmlFor="monthFilter" className="me-2">
            Select Month:
          </label>
          <input
            type="month"
            id="monthFilter"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            max={maxMonth}
            className="me-3 filter-month"
          />
        </div>

        <ReusableTable
          title="Monthly Attendance"
          data={monthlyData}
          columns={columns}
          initialEntriesPerPage={5}
          searchPlaceholder="Search users..."
          showSearch={true}
          showEntriesSelector={true}
          showPagination={true}
        />
      </div>
    </div>
  );
}

export default MonthlyAttendance;
