// src/components/AdminAttendence.js
import React, { useEffect, useState } from "react";
import { db } from "../../firebase/firebase";
import { collection, getDocs } from "firebase/firestore";
import { ThreeDots } from "react-loader-spinner";
import Navbar from "../../Shared/AdminSidebar/AdminSidebar";
import '../../Layout/Collapse/Collapse.css';
import ReusableTable from "../../Layout/ReusableTable";
import "./AdminAttendence.css";

const AdminAttendence = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [attendanceData, setAttendanceData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Convert Firestore timestamp → Indian time string
  const formatDateTime = (timestamp) => {
    if (!timestamp) return "N/A";
    const date = timestamp.toDate(); // Firestore timestamp → JS Date
    return date.toLocaleString("en-IN", {
      timeZone: "Asia/Kolkata",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
  };

  // Convert milliseconds → hh:mm:ss
  const formatDuration = (millis) => {
    if (!millis) return "N/A";
    const totalSeconds = Math.floor(millis / 1000);
    const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, "0");
    const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, "0");
    const seconds = String(totalSeconds % 60).padStart(2, "0");
    return `${hours}:${minutes}:${seconds}`;
  };

  const fetchAttendance = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, "attendance"));
      const attendance = [];

      querySnapshot.docs.forEach((doc) => {
        const data = doc.data();

        // Loop through each date key (e.g. "04-09-2025")
        Object.keys(data).forEach((dateKey) => {
          const record = data[dateKey];

          attendance.push({
            id: doc.id + "_" + dateKey,
            date: dateKey,
            employeeName: record.employeeName || "N/A",
            checkIn: record.checkIn ? formatDateTime(record.checkIn) : "N/A",
            checkInLocation: record.checkInLocation || "N/A",
            checkOut: record.checkOut ? formatDateTime(record.checkOut) : "N/A",
            checkOutLocation: record.checkOutLocation || "N/A",
            status: record.status || "N/A",
            duration: record.duration ? formatDuration(record.duration) : "N/A",
          });
        });
      });

      setAttendanceData(attendance);
    } catch (error) {
      console.error("Error fetching attendance:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAttendance();
  }, []);

  const columns = [
    {
      key: "sno",
      title: "S.No",
      render: (row, index) => index + 1,
    },
    { key: "date", title: "Date" },
    { key: "employeeName", title: "Name" },
    { key: "checkIn", title: "Check-In" },
    { key: "checkInLocation", title: "Check-In Location" },
    { key: "checkOut", title: "Check-Out" },
    { key: "checkOutLocation", title: "Check-Out Location" },
    { key: "status", title: "Status" },
    { key: "duration", title: "Duration" },
  ];

  if (loading) {
    return (
      <div className="loader-container">
        <ThreeDots
          height="80"
          width="80"
          radius="9"
          color="#00BFFF"
          ariaLabel="three-dots-loading"
          visible={true}
        />
      </div>
    );
  }

  return (
   <div className='CollapseContainer'>
      <Navbar onToggleSidebar={setCollapsed} />
      <div className={`Collapse ${collapsed ? 'collapsed' : ''}`}>
        <ReusableTable
          title="Employee Attendance"
          data={attendanceData}
          columns={columns}
          initialEntriesPerPage={5}
          searchPlaceholder="Search employees..."
          showSearch={true}
          showEntriesSelector={true}
          showPagination={true}
        />
      </div>
    </div>
  );
};

export default AdminAttendence;
