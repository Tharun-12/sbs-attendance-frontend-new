import React, { useState, useEffect } from "react";
import EmployeeSidebar from "../../Shared/EmployeeSidebar/EmployeeSidebar";
import { useAuth } from "../../Authcontext/Authcontext";
import { db } from "../../firebase/firebase";
import Employeetabs from "../../Shared/Employeetabs/EmployeeTabs";
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  Timestamp,
} from "firebase/firestore";
import axios from "axios";
import "./Attendence.css";

const Attendence = () => {
  const { user } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  // Attendance states
  const [checkedIn, setCheckedIn] = useState(false);
  const [checkedOut, setCheckedOut] = useState(false);
  const [checkInTime, setCheckInTime] = useState(null);
  const [checkOutTime, setCheckOutTime] = useState(null);
  const [status, setStatus] = useState("N/A");

  // NEW: Location states for check-in and check-out
  const [checkInLocation, setCheckInLocation] = useState("N/A");
  const [checkOutLocation, setCheckOutLocation] = useState("N/A");

  // Current location (for storing during check-in/out)
  const [address, setAddress] = useState("N/A");
  const [error, setError] = useState(null);

  // Format date as dd-mm-yyyy
  const formatDate = (date) => {
    const d = String(date.getDate()).padStart(2, "0");
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const y = date.getFullYear();
    return `${d}-${m}-${y}`;
  };
  const today = formatDate(new Date());

  // Fetch today's attendance
  useEffect(() => {
    const fetchAttendance = async () => {
      try {
        const attendanceRef = doc(db, "attendance", user.uid);
        const snap = await getDoc(attendanceRef);

        if (snap.exists() && snap.data()[today]) {
          const data = snap.data()[today];
          if (data.checkIn) {
            setCheckedIn(true);
            setCheckInTime(data.checkIn.toDate());
            setCheckInLocation(data.checkInLocation || "N/A"); // ✅ fetch check-in location
          }
          if (data.checkOut) {
            setCheckedOut(true);
            setCheckOutTime(data.checkOut.toDate());
            setCheckOutLocation(data.checkOutLocation || "N/A"); // ✅ fetch check-out location
          }
          if (data.status) {
            setStatus(data.status);
          }
        }
      } catch (err) {
        setError("Failed to fetch attendance.");
        console.error(err);
      }
    };
    fetchAttendance();
  }, [today, user.uid]);

  // Get current location
useEffect(() => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        try {
          const res = await axios.get(
            `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=AIzaSyAZAU88Lr8CEkiFP_vXpkbnu1-g-PRigXU&libraries=places`
          );

          if (res.data.status === "OK" && res.data.results?.length > 0) {
            // Take the most relevant formatted address
            const formatted = res.data.results[0].formatted_address;
            setAddress(formatted);
          } else {
            // Fallback
            setAddress(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
          }
        } catch (err) {
          console.error("Address fetch error:", err);
          setAddress(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
        }
      },
      (err) => {
        console.error("Location error:", err);
        setError("Unable to fetch location.");
      },
      { enableHighAccuracy: true }
    );
  }
}, []);



  // Handle check-in
  const handleCheckIn = async () => {
    const now = new Date();
    try {
      const attendanceRef = doc(db, "attendance", user.uid);
      const snap = await getDoc(attendanceRef);

      if (!snap.exists()) {
        await setDoc(attendanceRef, {});
      }

      await setDoc(
        attendanceRef,
        {
          [today]: {
            checkIn: Timestamp.fromDate(now),
            checkInLocation: address || "N/A",
            employeeName: user.fullName || "Unknown",
            status: "Present",
          },
        },
        { merge: true }
      );

      setCheckedIn(true);
      setCheckInTime(now);
      setCheckInLocation(address || "N/A"); // ✅ update local state
      setStatus("Present");
      alert("Checked in successfully");
    } catch (err) {
      console.error("Check-in error:", err);
      alert("Check-in failed: " + err.message);
    }
  };

  // Handle check-out
  const handleCheckOut = async () => {
    const now = new Date();
    try {
      const attendanceRef = doc(db, "attendance", user.uid);
      const snap = await getDoc(attendanceRef);

      if (!snap.exists()) {
        alert("No check-in found, please check in first!");
        return;
      }

      await updateDoc(attendanceRef, {
        [`${today}.checkOut`]: Timestamp.fromDate(now),
        [`${today}.checkOutLocation`]: address || "N/A",
        [`${today}.status`]: "Present",
      });

      setCheckedOut(true);
      setCheckOutTime(now);
      setCheckOutLocation(address || "N/A"); // ✅ update local state
      setStatus("Present");
      alert("Checked out successfully");
    } catch (err) {
      console.error("Check-out error:", err);
      alert("Check-out failed: " + err.message);
    }
  };

  return (
    <div className="employee-attendenceContainer1">
      <EmployeeSidebar onToggleSidebar={setCollapsed} />
      <div className={`employee-attendence1 ${collapsed ? "collapsed" : ""}`}>
        <h1 className="mt-4 text-center">My Attendance</h1>
        <div className="mt-3 mb-3">
          <Employeetabs />
        </div>

        <div className="attendance-card mt-3">
          <h5>
            Welcome,{" "}
            <span style={{ fontWeight: "bold", color: "cadetblue" }}>
              {user.fullName}
            </span>
          </h5>
          <p>
            <strong>Date:</strong> {today}
          </p>

          <div className="attendance-info">
            <p>
              <strong>Check-In:</strong>{" "}
              {checkInTime ? checkInTime.toLocaleTimeString() : "Not yet"}
            </p>
            <p>
              <strong>Check-In Location:</strong> {checkInLocation}
            </p>
            <p>
              <strong>Check-Out:</strong>{" "}
              {checkOutTime ? checkOutTime.toLocaleTimeString() : "Not yet"}
            </p>
            <p>
              <strong>Check-Out Location:</strong> {checkOutLocation}
            </p>
            <p>
              <strong>Status:</strong> {status}
            </p>
          </div>

          <div className="button-container">
            <button
              className="checkedIn-btn"
              onClick={handleCheckIn}
              disabled={checkedIn}
            >
              Check In
            </button>
            <button
              className="checkedOut-btn"
              onClick={handleCheckOut}
              disabled={!checkedIn || checkedOut}
            >
              Check Out
            </button>
          </div>

          {error && <p style={{ color: "red" }}>{error}</p>}
        </div>
      </div>
    </div>
  );
};

export default Attendence;
