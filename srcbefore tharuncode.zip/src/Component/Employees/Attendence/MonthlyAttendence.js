import React, { useState, useEffect } from 'react';
import { db } from '../../firebase/firebase';
import { collection, getDoc, doc } from 'firebase/firestore';
import { ThreeDots } from 'react-loader-spinner';
import EmployeeSidebar from '../../Shared/EmployeeSidebar/EmployeeSidebar';
import { useAuth } from '../../Authcontext/Authcontext';
import Employeetabs from '../../Shared/Employeetabs/EmployeeTabs';
import './MonthlyAttendence.css';

function EmployeeMonthlyAttendence() {
  const { user } = useAuth();

  // Utils
  const getFormattedMonth = (date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };

  const getMonthDates = (year, month) => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1));
  };

  const formatDateForKey = (date) => {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const [collapsed, setCollapsed] = useState(false);
  const [attendanceData, setAttendanceData] = useState({});
  const [currentDate] = useState(new Date());
  const [selectedMonth, setSelectedMonth] = useState(getFormattedMonth(new Date()));
  const [loading, setLoading] = useState(true);

  // Fetch attendance by uid
  const fetchAttendance = async () => {
    try {
      if (!user?.uid) return;
      const attendanceRef = doc(db, "attendance", user.uid);
      console.log("Fetching attendance for UID:", user.uid);
      const attendanceSnap = await getDoc(attendanceRef);
      console.log("Attendance Data:", attendanceSnap.data());

      if (attendanceSnap.exists()) {
        setAttendanceData(attendanceSnap.data());
      } else {
        setAttendanceData({});
      }
    } catch (error) {
      console.error("Error fetching attendance: ", error);
    }
  };

  useEffect(() => {
    fetchAttendance();
    setLoading(false);
  }, [user]);

  const processMonthlyAttendanceData = () => {
    const year = currentDate.getFullYear();
    const month = parseInt(selectedMonth.split('-')[1], 10) - 1;
    const monthDates = getMonthDates(year, month);
    const dateKeys = monthDates.map(formatDateForKey);

    let totalPresent = 0;
    const dailyStatuses = dateKeys.map((dateKey) => {
      const record = attendanceData[dateKey];
      if (record && record.status === "Present") {
        totalPresent++;
        return "P";
      } else {
        return "A";
      }
    });

    return {
      fullName: user.name || "N/A",
      dailyStatuses,
      totalPresent,
    };
  };

  const monthlyData = processMonthlyAttendanceData();

  const maxMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;

  if (loading) {
    return (
      <div className="loader-container">
        <ThreeDots
          height="80"
          width="80"
          radius="9"
          color="#00BFFF"
          ariaLabel="three-dots-loading"
          visible={true}
        />
      </div>
    );
  }

  return (
    <div className="employee-MonthlyAttendence">
      <EmployeeSidebar onToggleSidebar={setCollapsed} />
      <div className={`employee-MonthlyAttendence1 ${collapsed ? "collapsed" : ""}`}>
           <div className="employee-MonthlyAttendence1_tabs">
          <Employeetabs />
        </div>
        <div className="d-flex justify-content-center">
          
      
          <h1 className="employee-monthlyattendance-heading">
            Monthly Attendance 
            {/* {" "}
            {new Date(currentDate.getFullYear(), parseInt(selectedMonth.split("-")[1], 10) - 1).toLocaleString("default", { month: "long" })}{" "}
            {currentDate.getFullYear()} */}
          </h1>
        </div>

        <div className="d-flex justify-content-between mt-3">
          <div className="d-flex align-items-center">
            <label htmlFor="monthFilter" className="ms-3 me-2">
              Select Month:
            </label>
            <input
              type="month"
              id="monthFilter"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              max={maxMonth}
            />
          </div>
        </div>

       <div className="table-responsive mt-3">
  <table className="attendance-table">
    <thead>
      <tr>
        <th>Name</th>
        {getMonthDates(
          currentDate.getFullYear(),
          parseInt(selectedMonth.split("-")[1], 10) - 1
        ).map((date) => (
          <th key={date.getDate()}>{date.getDate().toString().padStart(2, "0")}</th>
        ))}
        <th>Present Days</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>{monthlyData.fullName}</td>
        {monthlyData.dailyStatuses.map((status, index) => (
          <td
            key={index}
            className={status === "P" ? "present" : "absent"}
          >
            {status}
          </td>
        ))}
        <td className="present-count">{monthlyData.totalPresent}</td>
      </tr>
    </tbody>
  </table>
</div>

      </div>
    </div>
  );
}

export default EmployeeMonthlyAttendence;
